#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include "getSeed.h"

int main()
{
    FILE *fPtr;
    fPtr = fopen("seed.txt", "r");
    char str[256];
    int seed, time, status_code;
    int activeChildren = 0;
    pid_t rc;
    int slugPID[4];
    char *numbers[] = {"1", "2", "3", "4"};


    for(int i = 0 ; i < 4; i++){
        rc = fork();
        char * const arguments[] = {"./slug", numbers[i], NULL};
        
        if(rc < 0){
            fprintf(stderr, "fork failed\n");
            exit(1);
        } else if(rc == 0){
            //slugPID[i] = getpid();
            //printf("Executing './slug %d' command...\n", i+1);
            status_code = execvp("./slug", arguments); // Will execute the command "last -l"
            if(status_code == -1){
            printf("ERROR\n");
            exit(1);
        }
        } else{
            printf("[Parent]: I forked off child %d.\n", rc);
            slugPID[i] = rc;
            activeChildren++;

            while(activeChildren > 0)  {
                printf("\n");
                int status;
                int waitReturn = waitpid(-1, &status, WNOHANG);

                for (int i = 0; i < 4; i++) {
                    if(slugPID[i])
                    if(waitReturn == -1){
                        if (slugPID[i] == waitReturn) {
                            activeChildren--;
                            printf("Slug %d with pid %d is dead\n", i+1, slugPID[i]);
                        }
                    } else if (waitReturn !=0 && waitReturn !=-1){
                        if (slugPID[i] == waitReturn){
                            activeChildren--;
                            slugPID[i] = 0;
                        }
                    } else{
                        usleep(0.33);
                        for (int i = 0; i < 4; i++) {
                            if (slugPID[i] != 0) {
                                printf("Slug %d with pid %d is still in the race\n", i+1, slugPID[i]);
                            }
                        }
                    }
                }
            }
        }
    }
    //printf("Print: %d, %d, %d, %d\n", slugPID[0], slugPID[1], slugPID[2], slugPID[3]);
    //while(slugPID[0] != 0 && )
    

    fclose(fPtr);
}
