For scenario 1, we are slightly confused with waitpid(), pid, and fork in general. The printf has too many duplicates.

We used 1D arrays and for loops in order to keep track of random numbers and the number of children. We tested the program by executing the gcc command in the cmd and also using the make command through the Makefile.

For the other scenarios I repeated the processes, I also used .h files to keep a common function.
