#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct job {
    int id ;
    int length ;
    int responseTime ;
    int turnaround ;
    int waitTime ;
    int workTime;
    // other meta data
    struct job * next ;
    };

typedef struct job LIST;

void swap(struct job *a, struct job *b){
    int temp = a->length;
    a->length = b->length;
    b->length = temp;

    int temp1 = a->id;
    a->id = b->id;
    b->id = temp1;
}

void bubbleSort (struct job *start){
    int swapped;
    struct job *ptr1;
    struct job *lptr = NULL;

    if (start == NULL)
        return;

    do {
        swapped = 0;
        ptr1 = start;

        while (ptr1->next != lptr){
            if (ptr1->length > ptr1->next->length){
                swap(ptr1, ptr1->next);
                swapped = 1;
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    }
    while(swapped);
}

int getCount(struct job *head){
    // Initialize count
    int count = 0;

    // Initialize current
    struct job *current = head;
    while (current->next != NULL)
    {
        count++;
        current = current->next;
    }
    count++;
    return count;
}

void rrFunc(struct job *head, int slice){
    int counter = 0;
    struct job *ptr1 = head;
    int tempResponse = 0;
    int loopCounter = 0;
    int totalLength = 0;
    float totalResponse = 0.00;
    float totalTurnaround = 0.00;
    float totalWait = 0.00;
    int gCounter = getCount(head);
    if(gCounter > 1){ // If there is only 1 node in linked list
        gCounter--;
    }

    while (counter < gCounter){
        while (ptr1->next != NULL){
            if(loopCounter == 0){
                ptr1->responseTime += tempResponse;
                ptr1->workTime = ptr1->length;
            }
            if (ptr1->length == 0)
                ptr1 = ptr1->next;
            else if (ptr1->length > slice){
                printf("Job %d ran for: %d\n", ptr1->id, slice);
                ptr1->length = ptr1->length - slice;
                totalLength += slice;
                tempResponse += slice;
                ptr1 = ptr1->next;
            }
            else{ //process done
                printf("Job %d ran for: %d\n", ptr1->id, ptr1->length);
                totalLength += ptr1->length;
                tempResponse += ptr1->length;
                ptr1->turnaround = totalLength;
                ptr1->length = 0;
                ptr1 = ptr1->next;
                counter++;
            }
            
        }

        if(loopCounter == 0){
            ptr1->responseTime += tempResponse;
            ptr1->workTime = ptr1->length;
        }
        if (ptr1->length > slice){
                printf("Job %d ran for: %d\n", ptr1->id, slice);
                ptr1->length = ptr1->length - slice;
                totalLength += slice;
                tempResponse += slice;
            }
        else if(ptr1->length != 0){ //process done
            printf("Job %d ran for: %d\n", ptr1->id, ptr1->length);
            totalLength += ptr1->length;
            tempResponse += ptr1->length;
            ptr1->turnaround = totalLength;
            ptr1->length = 0;
            counter++;
        }
        ptr1 = head;
        loopCounter++;
    }
    
    printf("End of execution with RR.\n");
    printf("Begin analyzing RR:\n");
    for (ptr1 = head; ptr1; ptr1 = ptr1->next){
        ptr1->waitTime = ptr1->turnaround - ptr1->workTime;
        totalResponse += ptr1->responseTime;
        totalTurnaround += ptr1->turnaround;
        totalWait += ptr1->waitTime;
        printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", ptr1->id, ptr1->responseTime, ptr1->turnaround, ptr1->waitTime);
    }
    printf("Average -- Response: %.2f  Turnaround: %.2f  Wait: %.2f\n", totalResponse/counter, totalTurnaround/counter, totalWait/counter);
}


void analysisFunc (struct job *head){
    struct job *current = head;
    int temp = 0;
    float totalResponse = 0.00;
    float totalTurnaround = 0.00;
    float totalWait = 0.00;
    int count = 0;
    for (current = head; current; current = current->next){
        current->responseTime += temp;
        totalResponse += current->responseTime;
        current->turnaround = current->length + temp;
        totalTurnaround += current->turnaround;
        current->waitTime += temp;
        totalWait += current->waitTime;
        temp += current->length;
        count++;
        printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", current->id, current->responseTime, current->turnaround, current->waitTime);
    }
    printf("Average -- Response: %.2f  Turnaround: %.2f  Wait: %.2f\n", totalResponse/count, totalTurnaround/count, totalWait/count);
}


int main(int argc, char **argv){

    FILE *fp;
    char line[128];
    LIST *current, *head;
    char* mainFile = argv[2];

    head = current = NULL;
    fp = fopen(mainFile, "r");

    int n = 0;

    while(fgets(line, sizeof(line), fp)){
        LIST *node = malloc(sizeof(LIST));
        node->length = atoi(line);
        node->id = n;
        n++;
        node->next = NULL;

        if (head == NULL){
            current = head = node;
        } 
        else {
            current = current->next = node;
        }
    }
    fclose(fp);


    if (strcmp(argv[1], "FIFO") == 0){
        printf("Execution trace with FIFO:\n");
        for (current = head; current; current = current->next){
            printf("Job %d ran for: %d\n", current->id, current->length);
        }
        printf("End of execution with FIFO.\n");

        printf("Begin analyzing FIFO:\n");
        analysisFunc(head);
        printf("End analyzing FIFO.\n");
    }
    
    else if (strcmp(argv[1], "SJF") == 0){
        bubbleSort(head);
        printf("Execution trace with SJF:\n");
        for (current = head; current; current = current->next){
            printf("Job %d ran for: %d\n", current->id, current->length);
        }
        printf("End of execution with SJF.\n");

        printf("Begin analyzing SJF:\n");
        analysisFunc(head);
        printf("End analyzing SJF.\n");
    }

    else if (strcmp(argv[1], "RR") == 0){
        printf("Execution trace with RR:\n");
        rrFunc(head, atoi(argv[3]));
        
        printf("End analyzing RR.\n");
    }


}



