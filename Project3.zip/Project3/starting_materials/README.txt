Katie Strogach & Hanna Trinh

For our project 3, we used structs and linked list where it contained members such as response time, turnaround time, wait time...etc. We developed a separate function to analyze FIFO and SJF which is called in main(), while RR has it's own function that has the analysis implemented inside. We also used a getCount() and bubbleSort() function found online (geekforGeeks) to do RR. 

Initially, we had a segmentation fault when trying to compile the RR func, we went soon realized that it was because of an if statement.

For workload 1: we know RR does a good job of not starving each process so in order to have the same response time and wait time, all the processes would need to have the same burst time.

For workload 2:

For workload 3: 

For workload 4:

For workload 5:


